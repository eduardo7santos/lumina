# Lumina Odontologia · site de demonstração (EK Landing Pages)

Landing page estática (HTML + CSS + JavaScript puro). Sem backend, sem build.
Site de demonstração · dados ilustrativos.

## Abrir localmente
Dê dois cliques em `index.html`. (As fontes Newsreader e Figtree vêm do Google Fonts; sem internet, a página usa Georgia e a fonte do sistema.)

## Estrutura
```
lumina-odontologia/
  index.html   conteúdo
  styles.css   estilos
  script.js    menu, FAQ, WhatsApp e fotos
  config.js    ÚNICO arquivo a editar: número de WhatsApp, mensagens e fotos
  README.md
  public/images/   coloque aqui as fotos (WebP/AVIF)
```

## Ligar o WhatsApp
Em `config.js`, preencha `whatsapp.number` (ex.: `"(49) 99999-9999"`). O link `https://wa.me/...` é gerado com a mensagem codificada; os botões dos tratamentos usam a mensagem própria de cada um.
Enquanto o número estiver vazio, os botões abrem um aviso de "Modo demonstração" e nada é enviado.

## Adicionar as fotos
Nenhuma foto vem incluída. Salve os arquivos em `public/images/` com estes nomes e preencha o `src` correspondente em `config.js`:

| Arquivo | Uso | Dimensão sugerida |
|---|---|---|
| hero-clinica.webp | Hero (consultório moderno) | 1600×1200 |
| recepcao-clinica.webp | Seção "A clínica" | 1200×1440 |
| profissional-ilustrativo.webp | Retrato ilustrativo | 1200×1440 |
| sala-espera.webp | Galeria | 1200×900 |
| consultorio.webp | Galeria | 1200×900 |
| ambiente-clinico.webp | Galeria | 1200×900 |

Sem o arquivo, a página mostra uma superfície em degradê azul com a legenda. Use imagens com licença própria ou geradas por você; não use banco de imagens como se fossem da clínica.

## Publicar grátis
- **Netlify:** arraste a pasta `lumina-odontologia` em app.netlify.com/drop.
- **Cloudflare Pages / GitHub Pages:** envie os arquivos e aponte a publicação para a raiz da pasta (sem comando de build).

## Depende de informações reais
Número de WhatsApp · nome e CRO do profissional · endereço e horário · formas de pagamento e convênios · fotos reais · domínio.
