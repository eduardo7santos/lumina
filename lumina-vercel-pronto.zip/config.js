/* ==========================================================
   LUMINA ODONTOLOGIA · CONFIGURAÇÃO CENTRAL
   Edite apenas este arquivo para ligar o WhatsApp e as fotos.
   ========================================================== */
window.LUMINA_CONFIG = {
  whatsapp: {
    // Número com DDD, só dígitos ou com máscara. Ex.: "(49) 99999-9999".
    // Deixe vazio ("") enquanto não houver número real.
    number: "",
    // Prefixo do país usado quando o número for informado sem ele (Brasil = 55).
    countryCode: "55"
  },

  messages: {
    default: "Olá! Gostaria de agendar uma avaliação.",
    treatments: {
      avaliacao: "Olá! Gostaria de saber mais sobre avaliação e prevenção.",
      limpeza: "Olá! Gostaria de saber mais sobre limpeza e profilaxia.",
      clareamento: "Olá! Gostaria de saber mais sobre clareamento dental.",
      ortodontia: "Olá! Gostaria de saber mais sobre ortodontia.",
      restauracoes: "Olá! Gostaria de saber mais sobre restaurações estéticas.",
      implantes: "Olá! Gostaria de saber mais sobre implantes."
    }
  },

  /* Fotos: os seis caminhos já estão definidos. Enquanto o arquivo não existir em
     public/images/, a página mostra o degradê azul; ao salvar o arquivo, a foto aparece sozinha.
     Ajuste width/height para as dimensões reais do arquivo. */
  images: {
    hero: {
      src: "public/images/hero-clinica.webp",
      alt: "Consultório odontológico moderno com cadeira de atendimento e luz natural",
      width: 1533, height: 1536
    },
    recepcao: {
      src: "public/images/recepcao-clinica.webp",
      alt: "Recepção acolhedora da clínica, com iluminação natural",
      width: 1521, height: 1536
    },
    profissional: {
      src: "public/images/profissional-ilustrativo.webp",
      alt: "Retrato ilustrativo de uma dentista em ambiente clínico",
      width: 1524, height: 1536
    },
    salaEspera: {
      src: "public/images/sala-espera.webp",
      alt: "Sala de espera ampla e organizada",
      width: 1536, height: 1533
    },
    consultorio: {
      src: "public/images/consultorio.webp",
      alt: "Consultório com equipamentos odontológicos e luz natural",
      width: 1533, height: 1536
    },
    ambienteClinico: {
      src: "public/images/ambiente-clinico.webp",
      alt: "Ambiente clínico limpo e organizado",
      width: 1530, height: 1536
    }
  }
};
