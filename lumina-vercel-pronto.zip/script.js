/* Lumina Odontologia · comportamento da página (JavaScript puro) */
(function () {
  "use strict";
  var CFG = window.LUMINA_CONFIG || {};
  var root = document.documentElement;

  /* ---------- WhatsApp ---------- */
  function normalizeNumber() {
    var wa = CFG.whatsapp || {};
    var digits = String(wa.number || "").replace(/\D/g, "").replace(/^0+/, "");
    if (!digits) return "";
    var cc = String(wa.countryCode || "").replace(/\D/g, "");
    if (cc && digits.indexOf(cc) !== 0) digits = cc + digits;
    return digits.length >= 10 && digits.length <= 15 ? digits : "";
  }

  function messageFor(key) {
    var m = CFG.messages || {};
    var t = m.treatments || {};
    return (key && t[key]) || m["default"] || "Olá! Gostaria de agendar uma avaliação.";
  }

  var number = normalizeNumber();
  var links = document.querySelectorAll("[data-wa]");
  var dialog = document.getElementById("demo-dialog");

  Array.prototype.forEach.call(links, function (a) {
    if (number) {
      a.href = "https://wa.me/" + number + "?text=" + encodeURIComponent(messageFor(a.getAttribute("data-wa")));
      a.target = "_blank";
      a.rel = "noopener noreferrer";
    } else {
      a.addEventListener("click", function (e) {
        e.preventDefault();
        if (dialog && typeof dialog.showModal === "function") {
          dialog.showModal();
        } else {
          window.alert("Modo demonstração: o WhatsApp desta clínica ainda não foi configurado (config.js).");
        }
      });
    }
  });

  /* ---------- Imagens (só entram se o arquivo estiver configurado) ---------- */
  var images = CFG.images || {};
  Array.prototype.forEach.call(document.querySelectorAll("[data-img]"), function (fig) {
    var key = fig.getAttribute("data-img");
    var cfg = images[key];
    if (!cfg || !cfg.src) return;
    var img = new Image();
    img.alt = cfg.alt || "";
    if (cfg.width) img.width = cfg.width;
    if (cfg.height) img.height = cfg.height;
    img.decoding = "async";
    if (key === "hero") {
      img.loading = "eager";
      img.setAttribute("fetchpriority", "high");
    } else {
      img.loading = "lazy";
    }
    img.addEventListener("load", function () { fig.insertBefore(img, fig.firstChild); });
    img.src = cfg.src; /* se o arquivo não existir, nada é exibido e a superfície azul permanece */
  });

  /* ---------- Menu mobile ---------- */
  var btn = document.querySelector(".menu-btn");
  var nav = document.getElementById("menu");
  var label = btn ? btn.querySelector(".sr-only") : null;

  function setMenu(open) {
    root.classList.toggle("menu-open", open);
    btn.setAttribute("aria-expanded", String(open));
    if (label) label.textContent = open ? "Fechar menu" : "Abrir menu";
  }
  if (btn && nav) {
    btn.addEventListener("click", function () { setMenu(!root.classList.contains("menu-open")); });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) setMenu(false); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && root.classList.contains("menu-open")) { setMenu(false); btn.focus(); }
    });
    window.matchMedia("(min-width:1024px)").addEventListener("change", function (e) { if (e.matches) setMenu(false); });
  }

  /* ---------- FAQ: um item aberto por vez ---------- */
  var items = document.querySelectorAll(".faq details");
  Array.prototype.forEach.call(items, function (d) {
    d.addEventListener("toggle", function () {
      if (!d.open) return;
      Array.prototype.forEach.call(items, function (o) { if (o !== d) o.open = false; });
    });
  });
})();
